package com.example.gordonramsdd;

import android.app.AlertDialog;
import android.app.DialogFragment;

/**
 * Created by Kevin on 11/20/2016.
 */

public class ConfirmDeletionDialogFragment extends DialogFragment{

}
